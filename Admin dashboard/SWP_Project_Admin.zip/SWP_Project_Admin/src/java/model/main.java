/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author acer
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Boolean check = AdminDao.login(new Admin("admin@gmail.com", "admin"));
//        System.out.println("" + check);
//        
//        List<Club> cl = new ClubDao().listAllClub();
//        System.out.println(cl);
    }
    
}
