/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dbcontext;

/**
 *
 * @author acer
 */
public interface DatabaseInfor {

    public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String url = "jdbc:sqlserver://LAPTOP-D3FL5ICO:1433;databaseName=FPTUCLUB;trustServerCertificate=true";
    public static String user = "sa";
    public static String pass = "Sy23112001";
}
